﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour
{
    [Header("Movement")]
    public bool swimming = false;

    protected Animator anim;

    void Awake()
    {
        anim = GetComponent<Animator>();
    }

    void Start()
    {
        Init();
    }

    protected virtual void Init()
    {

    }

    protected virtual void UpdateCharacter()
    {

    }

    void Update()
    {
        UpdateCharacter();
    }

}
